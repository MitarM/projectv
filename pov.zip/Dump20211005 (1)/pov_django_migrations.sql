-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: pov
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2021-10-05 08:51:16.080354'),(2,'auth','0001_initial','2021-10-05 08:51:17.340378'),(3,'account','0001_initial','2021-10-05 08:51:17.765306'),(4,'account','0002_auto_20210915_2037','2021-10-05 08:51:18.282577'),(5,'account','0003_volonter_cv','2021-10-05 08:51:18.449490'),(6,'account','0004_drzava','2021-10-05 08:51:18.497241'),(7,'account','0005_auto_20210925_2227','2021-10-05 08:51:20.382324'),(8,'account','0006_ulica_naselje','2021-10-05 08:51:20.479522'),(9,'account','0007_auto_20211005_1051','2021-10-05 08:51:21.442957'),(10,'admin','0001_initial','2021-10-05 08:51:21.931580'),(11,'admin','0002_logentry_remove_auto_add','2021-10-05 08:51:21.962335'),(12,'admin','0003_logentry_add_action_flag_choices','2021-10-05 08:51:21.993339'),(13,'ankete','0001_initial','2021-10-05 08:51:22.203088'),(14,'ankete','0002_auto_20210925_1654','2021-10-05 08:51:22.476993'),(15,'ankete','0003_auto_20210926_0956','2021-10-05 08:51:23.060212'),(16,'ankete','0004_auto_20210928_1847','2021-10-05 08:51:24.024415'),(17,'ankete','0005_pitanja_tip_pitanja','2021-10-05 08:51:24.135393'),(18,'ankete','0006_auto_20211002_1942','2021-10-05 08:51:24.595836'),(19,'ankete','0007_alter_stavka_glasovi','2021-10-05 08:51:24.625544'),(20,'contenttypes','0002_remove_content_type_name','2021-10-05 08:51:24.957945'),(21,'auth','0002_alter_permission_name_max_length','2021-10-05 08:51:25.107160'),(22,'auth','0003_alter_user_email_max_length','2021-10-05 08:51:25.229169'),(23,'auth','0004_alter_user_username_opts','2021-10-05 08:51:25.261173'),(24,'auth','0005_alter_user_last_login_null','2021-10-05 08:51:25.436160'),(25,'auth','0006_require_contenttypes_0002','2021-10-05 08:51:25.444400'),(26,'auth','0007_alter_validators_add_error_messages','2021-10-05 08:51:25.470401'),(27,'auth','0008_alter_user_username_max_length','2021-10-05 08:51:25.622718'),(28,'auth','0009_alter_user_last_name_max_length','2021-10-05 08:51:25.905066'),(29,'auth','0010_alter_group_name_max_length','2021-10-05 08:51:26.003774'),(30,'auth','0011_update_proxy_permissions','2021-10-05 08:51:26.036771'),(31,'auth','0012_alter_user_first_name_max_length','2021-10-05 08:51:26.185004'),(32,'forum','0001_initial','2021-10-05 08:51:26.919667'),(33,'forum','0002_auto_20210918_1419','2021-10-05 08:51:26.969104'),(34,'forum','0003_alter_diskusija_naziv','2021-10-05 08:51:27.050149'),(35,'forum','0004_auto_20210922_2050','2021-10-05 08:51:27.114284'),(36,'oglasi','0001_initial','2021-10-05 08:51:27.315171'),(37,'oglasi','0002_alter_oglas_autor','2021-10-05 08:51:27.572022'),(38,'oglasi','0003_oglas_datum_isteka_oglasa','2021-10-05 08:51:27.973034'),(39,'oglasi','0004_auto_20210918_1739','2021-10-05 08:51:28.203538'),(40,'oglasi','0005_auto_20210919_0907','2021-10-05 08:51:28.257544'),(41,'oglasi','0006_alter_oglas_datum_isteka_oglasa','2021-10-05 08:51:28.288547'),(42,'oglasi','0007_auto_20210919_0940','2021-10-05 08:51:28.544703'),(43,'oglasi','0008_alter_oglas_datum_isteka_oglasa','2021-10-05 08:51:28.578109'),(44,'oglasi','0009_auto_20210923_1620','2021-10-05 08:51:28.646044'),(45,'oglasi','0010_alter_oglas_datum_isteka_oglasa','2021-10-05 08:51:28.683407'),(46,'oglasi','0011_alter_oglas_datum_isteka_oglasa','2021-10-05 08:51:28.726655'),(47,'oglasi','0012_alter_oglas_datum_isteka_oglasa','2021-10-05 08:51:28.770043'),(48,'oglasi','0013_alter_oglas_datum_isteka_oglasa','2021-10-05 08:51:28.808046'),(49,'oglasi','0014_alter_oglas_datum_isteka_oglasa','2021-10-05 08:51:28.851053'),(50,'oglasi','0015_alter_oglas_datum_isteka_oglasa','2021-10-05 08:51:28.899053'),(51,'oglasi','0016_alter_oglas_datum_isteka_oglasa','2021-10-05 08:51:29.078042'),(52,'oglasi','0017_alter_oglas_datum_isteka_oglasa','2021-10-05 08:51:29.139376'),(53,'oglasi','0018_alter_oglas_datum_isteka_oglasa','2021-10-05 08:51:29.193380'),(54,'oglasi','0019_alter_oglas_datum_isteka_oglasa','2021-10-05 08:51:29.260384'),(55,'oglasi','0020_remove_oglas_datum_isteka_oglasa','2021-10-05 08:51:29.419271'),(56,'sessions','0001_initial','2021-10-05 08:51:29.503797');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-05 20:54:09
