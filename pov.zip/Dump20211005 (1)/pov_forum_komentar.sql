-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: pov
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `forum_komentar`
--

DROP TABLE IF EXISTS `forum_komentar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `forum_komentar` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sadrzaj` longtext NOT NULL,
  `datum` datetime(6) NOT NULL,
  `autor_id` int DEFAULT NULL,
  `diskusija_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `forum_komentar_autor_id_330d931f_fk_auth_user_id` (`autor_id`),
  KEY `forum_komentar_diskusija_id_3ab5a2f6_fk_forum_diskusija_id` (`diskusija_id`),
  CONSTRAINT `forum_komentar_autor_id_330d931f_fk_auth_user_id` FOREIGN KEY (`autor_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `forum_komentar_diskusija_id_3ab5a2f6_fk_forum_diskusija_id` FOREIGN KEY (`diskusija_id`) REFERENCES `forum_diskusija` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_komentar`
--

LOCK TABLES `forum_komentar` WRITE;
/*!40000 ALTER TABLE `forum_komentar` DISABLE KEYS */;
INSERT INTO `forum_komentar` VALUES (1,'fdadsfasd','2021-10-05 15:58:25.410205',4,1),(2,'dfas','2021-10-05 16:11:21.610193',4,1),(3,'dfad','2021-10-05 16:14:20.285525',1,1),(4,'asfadsd','2021-10-05 16:15:20.879577',4,1),(5,'fadsfa','2021-10-05 16:16:35.330207',4,1),(6,'Feugiat scelerisque varius morbi enim nunc faucibus a pellentesque. Id leo in vitae turpis. Dui faucibus in ornare quam viverra. Fermentum posuere urna nec tincidunt praesent semper feugiat nibh. Consectetur a erat nam at lectus urna. Mauris vitae ultricies leo integer. Egestas congue quisque egestas diam in arcu cursus. Pellentesque habitant morbi tristique senectus et netus et malesuada. Proin nibh nisl condimentum id venenatis a condimentum vitae. Arcu odio ut sem nulla pharetra diam sit amet nisl. Vestibulum lectus mauris ultrices eros. Elementum eu facilisis sed odio morbi quis commodo odio aenean. Ipsum suspendisse ultrices gravida dictum fusce ut placerat orci nulla. Aliquet nec ullamcorper sit amet risus. Nisi vitae suscipit tellus mauris a.','2021-10-05 18:40:10.376201',2,2);
/*!40000 ALTER TABLE `forum_komentar` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-05 20:54:11
