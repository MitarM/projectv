-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: pov
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `forum_diskusija`
--

DROP TABLE IF EXISTS `forum_diskusija`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `forum_diskusija` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `naziv` varchar(100) NOT NULL,
  `tekst` longtext NOT NULL,
  `datum` datetime(6) NOT NULL,
  `vidljivost` smallint unsigned NOT NULL,
  `vidljivost_za_org` smallint unsigned NOT NULL,
  `autor_id` int DEFAULT NULL,
  `kategorija_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `forum_diskusija_naziv_01170ee8_uniq` (`naziv`),
  KEY `forum_diskusija_kategorija_id_8fd7ccfa_fk_forum_kat` (`kategorija_id`),
  KEY `forum_diskusija_autor_id_85bd86e0_fk_auth_user_id` (`autor_id`),
  CONSTRAINT `forum_diskusija_autor_id_85bd86e0_fk_auth_user_id` FOREIGN KEY (`autor_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `forum_diskusija_kategorija_id_8fd7ccfa_fk_forum_kat` FOREIGN KEY (`kategorija_id`) REFERENCES `forum_kategorija_diskusije` (`id`),
  CONSTRAINT `forum_diskusija_chk_1` CHECK ((`vidljivost` >= 0)),
  CONSTRAINT `forum_diskusija_chk_2` CHECK ((`vidljivost_za_org` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_diskusija`
--

LOCK TABLES `forum_diskusija` WRITE;
/*!40000 ALTER TABLE `forum_diskusija` DISABLE KEYS */;
INSERT INTO `forum_diskusija` VALUES (1,'Д1','волонтера.\r\nЗакон је прецизан и у којим ситуацијама је волонтирање забрањено - то су послови опасни за живот и здравље или они који се обављају у условима опасним за живот и здравље.','2021-10-05 15:31:45.448256',1,1,2,1),(2,'Д2','Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','2021-10-05 17:47:13.072172',2,2,2,1),(3,'Д3','Id leo in vitae turpis massa sed elementum. Condimentum mattis pellentesque id nibh. Massa sed elementum tempus egestas sed. Eget egestas purus viverra accumsan in nisl nisi. Nulla facilisi etiam dignissim diam quis enim lobortis. Nisl nisi scelerisque eu ultrices vitae. Scelerisque mauris pellentesque pulvinar pellentesque habitant. Orci nulla pellentesque dignissim enim sit amet venenatis urna cursus. Risus feugiat in ante metus dictum at tempor commodo ullamcorper. Tincidunt ornare massa eget egestas purus viverra. Ultricies mi quis hendrerit dolor magna eget. Ultricies tristique nulla aliquet enim tortor at auctor. Tempor id eu nisl nunc mi ipsum faucibus. A diam maecenas sed enim ut sem viverra aliquet. Phasellus faucibus scelerisque eleifend donec pretium vulputate sapien. Dui nunc mattis enim ut tellus elementum sagittis vitae et. Euismod nisi porta lorem mollis aliquam. Fermentum dui faucibus in ornare quam viverra orci sagittis eu.\r\n\r\nArcu bibendum at varius vel pharetra. Commodo nulla facilisi nullam vehicula ipsum a arcu. Imperdiet sed euismod nisi porta. Iaculis urna id volutpat lacus laoreet non curabitur gravida. Mattis rhoncus urna neque viverra justo nec ultrices. Arcu bibendum at varius vel pharetra vel turpis. Diam donec adipiscing tristique risus nec feugiat in fermentum. Posuere urna nec tincidunt praesent semper. Aenean vel elit scelerisque mauris pellentesque pulvinar pellentesque. Placerat orci nulla pellentesque dignissim enim sit amet venenatis. Est lorem ipsum dolor sit amet.','2021-10-05 18:39:40.848968',2,1,2,2);
/*!40000 ALTER TABLE `forum_diskusija` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-05 20:54:12
