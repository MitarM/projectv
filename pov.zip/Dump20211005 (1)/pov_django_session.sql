-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: pov
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('9p0dvl96hwrvsgxd3o51qk2uzgj4ce4o','.eJxVjDsOwjAQBe_iGlnOxp-Ekp4zWOvdDQ4gW4qTCnF3iJQC2jcz76UibmuOW5MlzqzOyqrT75aQHlJ2wHcst6qplnWZk94VfdCmr5XleTncv4OMLX9rcOixC8mJJAIIvRkGL2zIj9YgsgEgS2PAaUJK1hoHjK7vhUm4I1bvD_DYONM:1mXpNx:VMRQXcZyPRgpStdJhV7fMha3_wxjz2anOcI9m8KfScY','2021-10-19 18:41:53.040535'),('i6zrs9bjlriz6q8bwes9zkfq18tumua3','.eJxVjEsOwiAUAO_C2pAHLS24dO8ZyPugVA0kpV0Z725IutDtzGTeKuK-5bi3tMZF1FkZdfplhPxMpQt5YLlXzbVs60K6J_qwTV-rpNflaP8GGVvuW2A3G0pehhtMhgLYEcSPzqXg2ARwlgGDZ-TZ4zBZttYZJLEJgSSozxfFrTeF:1mXniz:mWTyV3jRiN2dBRXFZoEivotaJfZYagOA3ERbXRuyGIw','2021-10-19 16:55:29.757823'),('s775k6s6836pbpy1w59bwjrj72wn18zm','.eJxVjDsOwjAQRO_iGln-YMVLSc8ZrPXuGgeQI8VJhbg7iZQCminmvZm3SrguNa1d5jSyuiinTr9dRnpK2wE_sN0nTVNb5jHrXdEH7fo2sbyuh_t3ULHXbR08QolinETvCxUGu2VGSzAQ0JmzZeaBDUQDPgQUh8TGcTQOJUT1-QIRlzj2:1mXoW9:7XEaa1732PqiDe0qgGgpFz_IQHc4L9AaHPRgUzlccGA','2021-10-19 17:46:17.755588');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-05 20:54:11
