-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: pov
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add stavka',7,'add_stavka'),(26,'Can change stavka',7,'change_stavka'),(27,'Can delete stavka',7,'delete_stavka'),(28,'Can view stavka',7,'view_stavka'),(29,'Can add anketa',8,'add_anketa'),(30,'Can change anketa',8,'change_anketa'),(31,'Can delete anketa',8,'delete_anketa'),(32,'Can view anketa',8,'view_anketa'),(33,'Can add oglas',9,'add_oglas'),(34,'Can change oglas',9,'change_oglas'),(35,'Can delete oglas',9,'delete_oglas'),(36,'Can view oglas',9,'view_oglas'),(37,'Can add volonter',10,'add_volonter'),(38,'Can change volonter',10,'change_volonter'),(39,'Can delete volonter',10,'delete_volonter'),(40,'Can view volonter',10,'view_volonter'),(41,'Can add organizacija',11,'add_organizacija'),(42,'Can change organizacija',11,'change_organizacija'),(43,'Can delete organizacija',11,'delete_organizacija'),(44,'Can view organizacija',11,'view_organizacija'),(45,'Can add drzava',12,'add_drzava'),(46,'Can change drzava',12,'change_drzava'),(47,'Can delete drzava',12,'delete_drzava'),(48,'Can view drzava',12,'view_drzava'),(49,'Can add mesto',13,'add_mesto'),(50,'Can change mesto',13,'change_mesto'),(51,'Can delete mesto',13,'delete_mesto'),(52,'Can view mesto',13,'view_mesto'),(53,'Can add ulica',14,'add_ulica'),(54,'Can change ulica',14,'change_ulica'),(55,'Can delete ulica',14,'delete_ulica'),(56,'Can view ulica',14,'view_ulica'),(57,'Can add interesovanje',15,'add_interesovanje'),(58,'Can change interesovanje',15,'change_interesovanje'),(59,'Can delete interesovanje',15,'delete_interesovanje'),(60,'Can view interesovanje',15,'view_interesovanje'),(61,'Can add dodatni podaci',16,'add_dodatnipodaci'),(62,'Can change dodatni podaci',16,'change_dodatnipodaci'),(63,'Can delete dodatni podaci',16,'delete_dodatnipodaci'),(64,'Can view dodatni podaci',16,'view_dodatnipodaci'),(65,'Can add diskusija',17,'add_diskusija'),(66,'Can change diskusija',17,'change_diskusija'),(67,'Can delete diskusija',17,'delete_diskusija'),(68,'Can view diskusija',17,'view_diskusija'),(69,'Can add kategorija_diskusije',18,'add_kategorija_diskusije'),(70,'Can change kategorija_diskusije',18,'change_kategorija_diskusije'),(71,'Can delete kategorija_diskusije',18,'delete_kategorija_diskusije'),(72,'Can view kategorija_diskusije',18,'view_kategorija_diskusije'),(73,'Can add komentar',19,'add_komentar'),(74,'Can change komentar',19,'change_komentar'),(75,'Can delete komentar',19,'delete_komentar'),(76,'Can view komentar',19,'view_komentar');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-05 20:54:12
