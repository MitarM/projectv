-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: localhost    Database: pov
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `oglasi_oglas`
--

DROP TABLE IF EXISTS `oglasi_oglas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oglasi_oglas` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `naslov` varchar(50) NOT NULL,
  `tekst` longtext NOT NULL,
  `datum` datetime(6) NOT NULL,
  `vidljivost` smallint unsigned NOT NULL,
  `za_brisanje` tinyint(1) NOT NULL,
  `arhiviran` tinyint(1) NOT NULL,
  `autor_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oglasi_oglas_autor_id_3cc4c330` (`autor_id`),
  CONSTRAINT `oglasi_oglas_autor_id_3cc4c330_fk_auth_user_id` FOREIGN KEY (`autor_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `oglasi_oglas_vidljivost_f7b2e10a_check` CHECK ((`vidljivost` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oglasi_oglas`
--

LOCK TABLES `oglasi_oglas` WRITE;
/*!40000 ALTER TABLE `oglasi_oglas` DISABLE KEYS */;
INSERT INTO `oglasi_oglas` VALUES (1,'Oglas1','Закон је прецизан и у којим ситуацијама је волонтирање забрањено - то су послови опасни за живот и здравље или они који се обављају у условима опасним за живот и здравље.','2021-10-05 16:16:59.754651',2,0,0,4),(2,'O2','Mattis rhoncus urna neque viverra. Nibh cras pulvinar mattis nunc. Dignissim enim sit amet venenatis. Arcu odio ut sem nulla pharetra. Tempus iaculis urna id volutpat lacus. Tristique sollicitudin nibh sit amet commodo nulla facilisi nullam vehicula. Velit dignissim sodales ut eu sem integer. Aliquam vestibulum morbi blandit cursus risus at ultrices mi tempus. Vitae auctor eu augue ut lectus. Facilisi cras fermentum odio eu. At volutpat diam ut venenatis. Ac tortor dignissim convallis aenean et tortor at risus. Adipiscing diam donec adipiscing tristique risus nec feugiat. Nibh mauris cursus mattis molestie a iaculis. Purus in massa tempor nec feugiat. Dui accumsan sit amet nulla facilisi morbi tempus. Donec ac odio tempor orci. Ullamcorper malesuada proin libero nunc consequat.\r\n\r\nUrna nunc id cursus metus. Augue interdum velit euismod in pellentesque massa placerat duis ultricies. Placerat vestibulum lectus mauris ultrices eros in cursus turpis massa. Donec pretium vulputate sapien nec. Blandit turpis cursus in hac habitasse platea dictumst quisque. Volutpat diam ut venenatis tellus in metus vulputate eu. Dignissim cras tincidunt lobortis feugiat. Aenean sed adipiscing diam donec adipiscing tristique. Risus pretium quam vulputate dignissim suspendisse in est ante. Morbi enim nunc faucibus a pellentesque sit. Non consectetur a erat nam at lectus. Ut porttitor leo a diam sollicitudin. Euismod lacinia at quis risus sed. Sit amet massa vitae tortor condimentum lacinia quis vel eros. Feugiat in ante metus dictum at tempor commodo ullamcorper a. Varius quam quisque id diam. Lectus proin nibh nisl condimentum id venenatis a. In eu mi bibendum neque egestas congue quisque egestas diam. Nibh cras pulvinar mattis nunc sed blandit libero volutpat.','2021-10-05 18:43:03.520243',1,0,0,4);
/*!40000 ALTER TABLE `oglasi_oglas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-05 20:54:11
